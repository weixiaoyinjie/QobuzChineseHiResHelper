# Qobuz 中文 Hi-Res 音乐资料助手 v1.0

这是**独立的 Android 中文音乐资料检索 App**，不是 Qobuz 官方客户端，不会翻译或修改 Qobuz 原生应用界面。

## 已包含的功能

1. 输入中文 / 繁体中文 / 英文 / 日文歌手名，查询 MusicBrainz（优先多语言别名），显示多个候选人，避免名字重复时选错歌手。
2. 内置常见歌手的中外文艺名离线对照；联网失败时也能一键复制。
3. 转换结果**可手动编辑**，一键复制到手机剪贴板，启动已安装的 Qobuz App，手动在 Qobuz 搜索栏粘贴。
4. 可尝试打开 Qobuz 网页搜索链接；若 Qobuz 不支持当前页面地址，以复制+启动 App 为可靠备选。
5. 根据歌手搜索专辑，显示首发日期、MusicBrainz 的发行版本、唱片公司、发行介质等资料；Cover Art Archive 提供封面（有资料时显示）。
6. TheAudioDB 补充歌手简介和流派（可能缺失）。
7. 歌手 / 专辑本地收藏，支持删除；全部无需服务器或数据库账号。
8. 独立的“找专辑”模式，允许直接搜索中文或英文专辑标题。

## 关键限制

- 它不会登录、控制或搜索你的 Qobuz 账户；无法代表 Qobuz 确认某个歌手或版本**必然被收录**。
- **MusicBrainz 的发行信息、实体封面不等于 Qobuz 的 Hi-Res 音频质量。** 24-bit / 192 kHz 等规格只以 Qobuz 内对应曲目的标识及实际播放链路为准。
- 自动寻找的是资料库里的艺名/别名，而非简单中文音译；同名歌手请先确认候选身份。
- Qobuz 官方应用是否会响应网页搜索链接取决于其版本和网站；本 App 采取先复制、再打开 App 的稳健方式，不声称支持未验证的直接搜索 Deep Link。
- 收藏保存在 Android 私有存储，卸载 App 可能清空收藏；第一版暂无跨设备同步。
- MusicBrainz 有约 1 次/秒的公共 API 限制，App 已对请求限速并使用明确的 User-Agent。
- 第三方接口可能限流或间歇不可用，网络错误会在界面显示。

## GitHub Actions 生成 APK

仓库建议名：`QobuzChineseHiResHelper`

1. 在 GitHub 新建**空仓库**，`Add file → Upload files`。
2. 手机最简单操作：**直接上传完整源码 ZIP 到仓库**，不用解压。然后建立 `.github/workflows/build-apk.yml`（把下载的工作流文件的内容完整复制进去）。
3. 另一种方式：先解压 ZIP，把 `settings.gradle`、`build.gradle`、`app/` 等项目文件放进仓库根目录，工作流文件放到 `.github/workflows/`。不要多套一层目录（本工作流也会尝试自动识别）。
4. 打开 `Actions → Build Qobuz Chinese Helper APK → Run workflow`。
5. 成功后在对应 workflow 运行页面的 Artifacts 下载 `QobuzChineseHiResHelper-debug`，解压得到 `app-debug.apk`，安装到手机。
6. **注意：**若仓库中已有多份源码 ZIP，应只保留当前这一份，以免自动选择到旧版本。

**注意**：该工程已经完成源文件与配置检查，但尚未在 Android SDK/GitHub Actions 下实际编译成功，首次工作流结果可能暴露需要修复的兼容性问题。

### GitHub Actions 版本

- `ubuntu-24.04`，JDK 17，Android SDK Platform 35，Build Tools 35.0.0，Gradle 8.11.1，Android Gradle Plugin 8.9.2。
- Android SDK 直接使用 GitHub Runner 预装组件，不使用 `android-actions/setup-android`。
- 没有外部依赖，界面使用 Android 原生 Java，最低 Android 8.0 (API 26)。

## API 资料

- MusicBrainz: https://musicbrainz.org/doc/MusicBrainz_API
- 别名说明: https://musicbrainz.org/doc/Aliases
- TheAudioDB: https://www.theaudiodb.com/free_music_api
- Cover Art Archive: https://musicbrainz.org/doc/Cover_Art_Archive/API

免费公开元数据接口，无 Qobuz 私有认证接口，也不需将 API 密钥写入仓库。
