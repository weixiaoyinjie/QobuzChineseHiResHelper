App 名称：Qobuz 中文 Hi-Res 音乐资料助手
GitHub 仓库建议：QobuzChineseHiResHelper
工作流：.github/workflows/build-apk.yml

目的：输入中文歌手名，获取音乐资料库的正式英文/国际艺名，复制并打开 Qobuz，手动粘贴搜索。也支持中文专辑检索、封面、发行年、唱片公司、收藏。

步骤（手机最方便）：新建空仓库→直接上传完整源码 ZIP（不需要解压）→在 .github/workflows/build-apk.yml 新建并粘贴编译代码→Actions→Build Qobuz Chinese Helper APK→Run workflow→下载 Artifact 里的 app-debug.apk。

提醒：本 App 不改变 Qobuz 自己的界面语言，不会自动在 Qobuz 内输入搜索文字，也不保证资料库查询到的专辑能在 Qobuz 播放。音乐规格要以 Qobuz 官方显示为准。

程序无第三方登录和私人数据库，收藏仅在手机本地。该版尚未经过 GitHub Actions 真机编译确认。
