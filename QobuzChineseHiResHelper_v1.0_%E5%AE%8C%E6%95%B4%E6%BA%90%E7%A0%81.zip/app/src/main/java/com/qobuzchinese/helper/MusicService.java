package com.qobuzchinese.helper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Public metadata only. No Qobuz credentials, scraping or private endpoints. */
public final class MusicService {
    private static final String MB = "https://musicbrainz.org/ws/2/";
    private static long lastMbCall = 0;
    private static final String AGENT = "QobuzChineseHiResHelper/1.0 (https://github.com/weixiaoyinjie)";

    static final class Artist {
        String id, name, original, country, extra, source;
        int score;
        final ArrayList<String> aliases = new ArrayList<>();
        Artist(String id, String name, String original, String source) {
            this.id = id; this.name = name; this.original = original; this.source = source;
            this.country = ""; this.extra = "";
        }
    }
    static final class Album {
        String id, name, year, type, artist, label;
        Album(String id, String name, String year, String type, String artist) {
            this.id = id; this.name = name; this.year = year; this.type = type; this.artist = artist;
            this.label = "";
        }
        String imageUrl() { return "https://coverartarchive.org/release-group/" + id + "/front-250"; }
    }
    static final class Extra {
        String biography = "", genre = "", image = "";
    }

    private static String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception ignored) { return s; } }
    private static String opt(JSONObject j, String key) { return j == null ? "" : j.optString(key, ""); }

    private static synchronized void limitMusicBrainz() throws InterruptedException {
        long now = System.currentTimeMillis();
        long sleep = 1150 - (now - lastMbCall);
        if (sleep > 0) Thread.sleep(sleep);
        lastMbCall = System.currentTimeMillis();
    }
    private static byte[] request(String address, boolean isMb, int cap) throws Exception {
        if (isMb) limitMusicBrainz();
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        try {
            c.setRequestMethod("GET");
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", AGENT);
            c.setRequestProperty("Accept", "application/json");
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("服务暂不可用 (HTTP " + code + ")");
            try (InputStream stream = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b = new byte[8192]; int n;
                while ((n = stream.read(b)) >= 0) {
                    out.write(b, 0, n);
                    if (out.size() > cap) throw new Exception("响应内容过大");
                }
                return out.toByteArray();
            }
        } finally { c.disconnect(); }
    }
    private static JSONObject json(String address, boolean mb) throws Exception {
        return new JSONObject(new String(request(address, mb, 3_000_000), StandardCharsets.UTF_8));
    }
    public static Bitmap fetchCover(String url) {
        try {
            byte[] data = request(url, false, 1_200_000);
            return BitmapFactory.decodeByteArray(data, 0, data.length);
        } catch (Exception ignored) { return null; }
    }
    public static List<Artist> searchArtists(String query) throws Exception {
        JSONObject obj = json(MB + "artist/?query=" + enc(query.trim()) + "&limit=12&fmt=json", true);
        JSONArray rows = obj.optJSONArray("artists");
        List<Artist> list = new ArrayList<>();
        if (rows == null) return list;
        for (int i=0; i<rows.length(); i++) {
            JSONObject item = rows.optJSONObject(i);
            if (item == null) continue;
            String name = opt(item, "name");
            String id = opt(item, "id");
            if (id.isEmpty() || name.isEmpty()) continue;
            Artist a = new Artist(id, name, name, "MusicBrainz");
            a.score = item.optInt("score", 0);
            a.country = opt(item, "country");
            a.extra = opt(item, "disambiguation");
            JSONArray aliases = item.optJSONArray("aliases");
            if (aliases != null) for (int k=0;k<aliases.length();k++) {
                JSONObject alias = aliases.optJSONObject(k);
                if (alias!=null) addAlias(a, opt(alias,"name"));
            }
            a.name = preferLatin(a.name, aliases);
            list.add(a);
        }
        return list;
    }
    private static void addAlias(Artist a, String alias) {
        if (alias != null && !alias.isEmpty() && !a.aliases.contains(alias) && a.aliases.size()<20) a.aliases.add(alias);
    }
    private static boolean containsLatin(String s) {
        return s != null && s.matches(".*[A-Za-z].*") && !s.matches(".*[\\u4e00-\\u9fff\\u3040-\\u30ff\\uac00-\\ud7af].*");
    }
    private static String preferLatin(String current, JSONArray aliases) {
        if (containsLatin(current)) return current;
        if (aliases == null) return current;
        String first = "";
        for (int i=0; i<aliases.length();i++) {
            JSONObject alias=aliases.optJSONObject(i);
            if (alias==null) continue;
            String name=opt(alias,"name"), locale=opt(alias,"locale");
            if (!containsLatin(name)) continue;
            if (first.isEmpty()) first=name;
            if (locale.toLowerCase(Locale.ROOT).startsWith("en")) return name;
        }
        return first.isEmpty() ? current : first;
    }
    public static Artist artistDetails(Artist a) throws Exception {
        if (a.id == null || a.id.isEmpty()) return a;
        JSONObject obj = json(MB + "artist/" + enc(a.id) + "?inc=aliases&fmt=json",true);
        a.original = opt(obj,"name");
        a.country=opt(obj,"country");
        a.extra=opt(obj,"disambiguation");
        JSONArray aliases=obj.optJSONArray("aliases");
        if (aliases!=null) for(int k=0;k<aliases.length();k++) {
            JSONObject alias=aliases.optJSONObject(k);
            if (alias!=null) addAlias(a, opt(alias,"name"));
        }
        a.name=preferLatin(a.original,aliases);
        return a;
    }
    public static List<Album> searchAlbums(String query) throws Exception {
        List<Album> list=new ArrayList<>();
        JSONObject obj=json(MB+"release-group/?query="+enc(query.trim())+"&limit=18&fmt=json",true);
        JSONArray rows=obj.optJSONArray("release-groups");
        if(rows==null)return list;
        for(int i=0;i<rows.length();i++) {
            JSONObject row=rows.optJSONObject(i); if(row==null)continue;
            String id=opt(row,"id"), title=opt(row,"title"), artist="";
            if(id.isEmpty()||title.isEmpty())continue;
            JSONArray credited=row.optJSONArray("artist-credit");
            if(credited!=null)for(int k=0;k<credited.length();k++) {
                JSONObject credit=credited.optJSONObject(k);
                if(credit!=null){ JSONObject ar=credit.optJSONObject("artist");
                    if(ar!=null){artist=opt(ar,"name");break;} }
            }
            list.add(new Album(id,title,opt(row,"first-release-date"),opt(row,"primary-type"),artist));
        }
        return list;
    }
    public static List<Album> albumsByArtist(Artist a) throws Exception {
        List<Album> list=new ArrayList<>();
        if (a.id==null || a.id.isEmpty()) return list;
        JSONObject obj=json(MB + "release-group/?artist=" + enc(a.id) + "&type=album&limit=30&fmt=json",true);
        JSONArray rows=obj.optJSONArray("release-groups");
        if(rows==null) return list;
        for(int i=0;i<rows.length();i++) {
            JSONObject row=rows.optJSONObject(i); if(row==null) continue;
            String id=opt(row,"id"), title=opt(row,"title");
            if(id.isEmpty()||title.isEmpty()) continue;
            String date=opt(row,"first-release-date"), type=opt(row,"primary-type");
            list.add(new Album(id,title,date,type,a.name));
        }
        list.sort((a1,a2)->a2.year.compareTo(a1.year));
        return list;
    }
    public static String albumEditionDetails(Album album) throws Exception {
        JSONObject listings=json(MB+"release/?release-group="+enc(album.id)+"&limit=8&fmt=json",true);
        JSONArray rows=listings.optJSONArray("releases");
        if(rows==null || rows.length()==0) return "MusicBrainz 暂无发行版本资料。";
        JSONObject first=rows.optJSONObject(0);
        if(first==null) return "缺少版本资料";
        StringBuilder out=new StringBuilder();
        out.append("版本记录（显示前 ").append(rows.length()).append(" 条）\n");
        for(int i=0;i<rows.length();i++) {
            JSONObject r=rows.optJSONObject(i); if(r==null)continue;
            out.append("• ").append(opt(r,"date")).append("  ").append(opt(r,"country"));
            String dis=opt(r,"disambiguation");if(!dis.isEmpty())out.append("  ").append(dis);
            out.append("\n");
        }
        String relId=opt(first,"id");
        if(!relId.isEmpty()) {
            JSONObject rel=json(MB+"release/"+enc(relId)+"?inc=labels+media&fmt=json",true);
            JSONArray infos=rel.optJSONArray("label-info");
            if(infos!=null)for(int i=0;i<infos.length();i++) {
                JSONObject info=infos.optJSONObject(i);if(info==null)continue;
                JSONObject label=info.optJSONObject("label");
                if(label!=null && !opt(label,"name").isEmpty()) out.append("唱片公司：").append(opt(label,"name")).append("\n");
                if(!opt(info,"catalog-number").isEmpty())out.append("目录编号：").append(opt(info,"catalog-number")).append("\n");
            }
            JSONArray media=rel.optJSONArray("media");
            if(media!=null && media.length()>0) {
                JSONObject m=media.optJSONObject(0); if(m!=null)out.append("发行媒介：").append(opt(m,"format")).append("\n");
            }
        }
        out.append("\n注意：这些是发行资料，不代表 Qobuz 实际提供的音质或版本。");
        return out.toString();
    }
    public static Extra audioDbArtist(String name) throws Exception {
        JSONObject j=json("https://www.theaudiodb.com/api/v1/json/123/search.php?s="+enc(name),false);
        Extra e=new Extra();
        JSONArray rows=j.optJSONArray("artists");if(rows==null || rows.length()==0)return e;
        JSONObject a=rows.optJSONObject(0);if(a==null)return e;
        e.genre=opt(a,"strGenre");e.image=opt(a,"strArtistThumb");
        e.biography=opt(a,"strBiographyCN");
        if(e.biography.isEmpty())e.biography=opt(a,"strBiographyEN");
        if(e.biography.length()>600)e.biography=e.biography.substring(0,600)+"…";
        return e;
    }
}
