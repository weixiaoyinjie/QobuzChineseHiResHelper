package com.qobuzchinese.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(12,17,29), CARD=Color.rgb(26,34,52), INPUT=Color.rgb(34,43,62);
    private static final int WHITE=Color.rgb(241,246,252), MUTED=Color.rgb(166,181,198), ACCENT=Color.rgb(72,209,178);
    private static final String STORE="qobuz_chinese_favorites_v1";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ExecutorService artwork=Executors.newFixedThreadPool(2);
    private EditText searchInput, qobuzInput;
    private LinearLayout content;
    private TextView state;
    private int mode=0, token=0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(BG);
        page.setPadding(dp(16),dp(18),dp(16),dp(8));setContentView(page);
        page.addView(text("Qobuz 中文音乐助手",24,WHITE,true));
        page.addView(text("中文歌手 → 国际艺名 · Hi-Res 专辑资料 · 收藏",12,MUTED,false));
        page.addView(space(13));
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        addWideButton(nav,"找歌手",()->{mode=0;searchInput.setHint("输入中文歌手名，如：邓丽君");},true);
        addWideButton(nav,"找专辑",()->{mode=1;searchInput.setHint("输入专辑名称（中文/英文）");},false);
        addWideButton(nav,"我的收藏",this::showFavorites,false);
        page.addView(nav); page.addView(space(12));
        LinearLayout searchBar=new LinearLayout(this);searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchInput=new EditText(this);searchInput.setSingleLine(true);searchInput.setTextSize(16);searchInput.setTextColor(WHITE);
        searchInput.setHintTextColor(MUTED);searchInput.setHint("输入中文歌手名，如：邓丽君");
        searchInput.setPadding(dp(12),0,dp(8),0);searchInput.setBackground(round(INPUT,12));
        LinearLayout.LayoutParams editParams=new LinearLayout.LayoutParams(0,dp(51),1);editParams.setMargins(0,0,dp(8),0);searchBar.addView(searchInput,editParams);
        Button search=button("搜索",()->search(),true);
        searchBar.addView(search,new LinearLayout.LayoutParams(dp(84),dp(51)));
        page.addView(searchBar);page.addView(space(9));
        state=text("支持中文、英文、日文艺名；搜索结果请核对歌手身份。",12,MUTED,false);page.addView(state);
        ScrollView scroller=new ScrollView(this);scroller.setFillViewport(true);scroller.setVerticalScrollBarEnabled(false);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(12),0,dp(25));
        scroller.addView(content);page.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=text("非 Qobuz 官方 App · 不需要 Qobuz 密码 · 本地收藏",11,MUTED,false);
        foot.setGravity(Gravity.CENTER); page.addView(foot);
        showWelcome();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color,boolean strong){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(strong)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setLineSpacing(dp(2),1.04f);return t;
    }
    private View space(int size){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(size)));return v;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout card(){
        LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);v.setPadding(dp(14),dp(14),dp(14),dp(14));
        v.setBackground(round(CARD,15));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(11));content.addView(v,p);return v;
    }
    private void add(LinearLayout parent,String s,int size,int color,boolean strong){parent.addView(text(s,size,color,strong));}
    private Button button(String s,Runnable r,boolean accent){
        Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setPadding(dp(5),0,dp(5),0);
        b.setTextColor(accent?BG:WHITE);b.setBackground(round(accent?ACCENT:INPUT,11));
        b.setOnClickListener(v->r.run());return b;
    }
    private void addWideButton(LinearLayout row,String name,Runnable action,boolean accent){
        Button b=button(name,action,accent);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(43),1);
        p.setMargins(dp(2),0,dp(2),0);row.addView(b,p);
    }
    private LinearLayout actionRow(LinearLayout box){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(10),0,0);box.addView(row,p);return row;
    }
    private void note(String s){state.setText(s);}
    private void hideKeyboard(){
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(searchInput.getWindowToken(),0);
        searchInput.clearFocus();
    }
    private void showWelcome(){
        content.removeAllViews();LinearLayout intro=card();add(intro,"按中文歌手名搜索",19,WHITE,true);
        add(intro,"搜索邓丽君、周杰伦、宇多田光等，识别 MusicBrainz 中的国际艺名；手动确认后，一键复制并打开 Qobuz。",14,MUTED,false);
        add(intro,"\n专辑资料会展示发行年份、专辑封面、发行版本和唱片公司。实际 Qobuz Hi-Res 位深/采样率仍需在 Qobuz 中确认。",13,MUTED,false);
        LinearLayout row=actionRow(intro);
        addWideButton(row,"试试：邓丽君",()->{searchInput.setText("邓丽君");mode=0;search();},true);
        addWideButton(row,"试试：周杰伦",()->{searchInput.setText("周杰伦");mode=0;search();},false);
    }
    private void search(){
        String input=searchInput.getText().toString().trim();
        if(input.isEmpty()){toast("请输入歌手或专辑名称");return;}
        if(input.length()>100){toast("搜索词请小于100个字符");return;}
        hideKeyboard();int active=++token;content.removeAllViews();
        note("正在搜索音乐资料…");
        if(mode==0){
            MusicService.Artist off=offline(input);
            if(off!=null){add(content,"离线对照（可立即使用）",14,ACCENT,true); artistCard(off,active);}
            worker.execute(()->{
                try{
                    List<MusicService.Artist> list=MusicService.searchArtists(input);
                    runOnUiThread(()->{if(active!=token)return;
                        note("搜索到 "+list.size()+" 条歌手记录；请选择正确歌手。");
                        if(list.isEmpty()){if(off==null)message("没有匹配的歌手", "可尝试简体/繁体、英文名称，或使用手动输入搜索词。");}
                        else{add(content,"MusicBrainz 在线查询结果",16,WHITE,true);content.addView(space(10));
                            for(MusicService.Artist a:list)artistCard(a,active);}
                        if(off==null)manualCard(input,active);
                    });
                }catch(Exception e){runOnUiThread(()->{if(active!=token)return;
                    note("网络查询失败："+e.getMessage()+"。仍可以手动使用搜索词。");
                    if(off==null)manualCard(input,active);
                });}
            });
        }else{
            worker.execute(()->{
                try{
                    List<MusicService.Album> list=MusicService.searchAlbums(input);
                    runOnUiThread(()->{if(active!=token)return;
                        content.removeAllViews();note("查询到 "+list.size()+" 张专辑（发行信息，不保证 Qobuz 收录）。");
                        if(list.isEmpty())message("暂无专辑结果","试试原文标题、英文标题或先找歌手。");
                        for(MusicService.Album a:list)albumCard(a,active);
                    });
                }catch(Exception e){runOnUiThread(()->{if(active!=token)return;note("在线查询失败："+e.getMessage());message("搜索失败","请检查网络后重试。");});}
            });
        }
    }
    private MusicService.Artist offline(String input){
        String name=LocalNames.get(input);if(name==null)return null;
        MusicService.Artist a=new MusicService.Artist("",name,input,"离线常见艺名对照");a.aliases.add(input);return a;
    }
    private void manualCard(String input,int active){
        MusicService.Artist a=new MusicService.Artist("",input,input,"手动查询词");artistCard(a,active);
    }
    private void message(String head,String body){LinearLayout c=card();add(c,head,16,WHITE,true);add(c,body,13,MUTED,false);}
    private void artistCard(MusicService.Artist a,int active){
        LinearLayout c=card();add(c,a.name,18,WHITE,true);
        String info=a.source+(a.country.isEmpty()?"":" · "+a.country)+(a.extra.isEmpty()?"":" · "+a.extra);
        add(c,info,12,MUTED,false);
        if(!a.aliases.isEmpty())add(c,"别名："+joinNames(a.aliases,5),12,MUTED,false);
        LinearLayout row=actionRow(c);
        addWideButton(row,"查看 / 转换",()->selectArtist(a),true);
        addWideButton(row,"复制艺名",()->copy(a.name),false);
    }
    private String joinNames(List<String> names,int limit){StringBuilder b=new StringBuilder();int count=0;
        for(String name:names){if(name.length()>48)continue;if(count++>=limit)break;if(b.length()>0)b.append(" / ");b.append(name);}
        return b.toString();
    }
    private void selectArtist(MusicService.Artist artist){
        int active=++token;content.removeAllViews();note("正在获取歌手详情…");
        renderArtist(artist,active);
        if(artist.id == null || !artist.id.matches("[0-9a-fA-F-]{36}")){note("离线或手动匹配结果，可以直接复制艺名；若要看专辑，请选择 MusicBrainz 在线歌手。");return;}
        worker.execute(()->{
            try{
                MusicService.Artist detailed=MusicService.artistDetails(artist);
                List<MusicService.Album> albums=MusicService.albumsByArtist(detailed);
                runOnUiThread(()->{if(active!=token)return;
                    content.removeAllViews();renderArtist(detailed,active);
                    note("找到歌手资料和 "+albums.size()+" 张专辑记录。\n请检查所选歌手与中文姓名是否对应。");
                    add(content,"专辑与发行年份",17,WHITE,true);content.addView(space(9));
                    if(albums.isEmpty())message("暂无专辑资料","换一个艺名或在 Qobuz 内搜索。");
                    for(int i=0;i<Math.min(25,albums.size());i++)albumCard(albums.get(i),active);
                });
                try{
                    MusicService.Extra ex=MusicService.audioDbArtist(detailed.name);
                    runOnUiThread(()->{if(active!=token)return;
                        if((ex.genre!=null&&!ex.genre.isEmpty())||(ex.biography!=null&&!ex.biography.isEmpty())){
                            LinearLayout c=card();add(c,"TheAudioDB 补充介绍",15,WHITE,true);
                            if(!ex.genre.isEmpty())add(c,"音乐风格："+ex.genre,13,ACCENT,false);
                            if(!ex.biography.isEmpty())add(c,ex.biography,12,MUTED,false);
                        }
                    });
                }catch(Exception ignored){}
            }catch(Exception err){runOnUiThread(()->{if(active!=token)return;note("歌手详情加载不完整："+err.getMessage()+"，仍可复制艺名并搜索 Qobuz。");});}
        });
    }
    private void renderArtist(MusicService.Artist artist,int active){
        LinearLayout c=card();add(c,"歌手与 Qobuz 搜索词",14,ACCENT,true);
        add(c,artist.name,22,WHITE,true);
        if(!artist.original.equals(artist.name))add(c,"原文名称："+artist.original,13,MUTED,false);
        if(artist.country!=null&&!artist.country.isEmpty())add(c,"地区："+artist.country,12,MUTED,false);
        if(!artist.aliases.isEmpty())add(c,"多语言别名："+joinNames(artist.aliases,10),12,MUTED,false);
        c.addView(space(7));add(c,"可以手动修改下方搜索词，避免数据库别名不符合 Qobuz 收录名称。",12,MUTED,false);
        qobuzInput=new EditText(this);qobuzInput.setSingleLine(true);qobuzInput.setText(artist.name);
        qobuzInput.setTextColor(WHITE);qobuzInput.setTextSize(18);qobuzInput.setBackground(round(INPUT,11));
        qobuzInput.setPadding(dp(12),0,dp(12),0);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(52));ep.setMargins(0,dp(8),0,0);c.addView(qobuzInput,ep);
        LinearLayout row=actionRow(c);
        addWideButton(row,"复制名字",()->copy(qobuzInput.getText().toString()),true);
        addWideButton(row,"打开 Qobuz",()->openQobuz(qobuzInput.getText().toString()),false);
        addWideButton(row,"网页搜索",()->webQobuz(qobuzInput.getText().toString()),false);
        LinearLayout row2=actionRow(c);
        addWideButton(row2,"☆ 收藏歌手",()->saveFavorite("artist",artist.id,artist.name,artist.original),false);
        addWideButton(row2,"返回搜索",()->search(),false);
        add(c,"\n注：打开 Qobuz 时会把搜索词复制到剪贴板，请到 Qobuz 搜索栏粘贴。不会自动操作第三方 App。",12,MUTED,false);
    }
    private void albumCard(MusicService.Album a,int active){
        LinearLayout c=card();LinearLayout horizontal=new LinearLayout(this);horizontal.setOrientation(LinearLayout.HORIZONTAL);c.addView(horizontal);
        ImageView cover=new ImageView(this);cover.setImageResource(android.R.drawable.ic_menu_gallery);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);cover.setBackground(round(INPUT,8));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(79),dp(79));cp.setMargins(0,0,dp(12),0);horizontal.addView(cover,cp);
        LinearLayout infos=new LinearLayout(this);infos.setOrientation(LinearLayout.VERTICAL);horizontal.addView(infos,new LinearLayout.LayoutParams(0,-2,1));
        add(infos,a.name,15,WHITE,true);if(a.artist!=null&&!a.artist.isEmpty())add(infos,a.artist,12,ACCENT,false);
        add(infos,"首次发行："+(a.year.isEmpty()?"未知":a.year)+(a.type.isEmpty()?"":" · "+a.type),12,MUTED,false);
        LinearLayout row=actionRow(c);
        addWideButton(row,"版本 / 唱片公司",()->albumDetails(a),true);
        addWideButton(row,"☆ 收藏",()->saveFavorite("album",a.id,a.name,a.artist+" · "+a.year),false);
        addWideButton(row,"Qobuz",()->openQobuz((a.artist==null?"":a.artist+" ")+a.name),false);
        artwork.execute(()->{Bitmap bitmap=MusicService.fetchCover(a.imageUrl());if(bitmap!=null)
            runOnUiThread(()->{if(active==token&&!isFinishing())cover.setImageBitmap(bitmap);});});
    }
    private void albumDetails(MusicService.Album a){
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(a.name).setMessage("正在查询版本和唱片公司…")
            .setPositiveButton("关闭",(d,w)->{}).create();dialog.show();
        worker.execute(()->{
            try{String data=MusicService.albumEditionDetails(a);
                runOnUiThread(()->{if(dialog.isShowing())dialog.setMessage(data);});
            }catch(Exception e){runOnUiThread(()->{if(dialog.isShowing())dialog.setMessage("查询暂时失败："+e.getMessage());});}
        });
    }
    private void copy(String val){
        if(val==null||val.trim().isEmpty()){toast("搜索词为空");return;}
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("Qobuz 搜索词",val.trim()));toast("已复制："+val.trim());
    }
    private void openQobuz(String val){
        copy(val);
        Intent intent=getPackageManager().getLaunchIntentForPackage("com.qobuz.music");
        if(intent==null){toast("没有检测到 Qobuz，尝试打开官网");openUrl("https://www.qobuz.com/");return;}
        try{startActivity(intent);}catch(Exception e){toast("无法启动 Qobuz，请检查是否已安装。");}
    }
    private void webQobuz(String val){
        if(val==null || val.trim().isEmpty()){toast("搜索词为空");return;}
        String q;try {q=URLEncoder.encode(val.trim(),"UTF-8");}catch(Exception e){q=val.trim();}
        openUrl("https://www.qobuz.com/search?q="+q);
    }
    private void openUrl(String url){
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}
        catch(Exception e){toast("未找到浏览器");}
    }
    private SharedPreferences prefs(){return getSharedPreferences(STORE,MODE_PRIVATE);}
    private JSONArray favorites(){try{return new JSONArray(prefs().getString("items","[]"));}catch(Exception e){return new JSONArray();}}
    private void saveFavorite(String kind,String id,String title,String extra){
        if(id==null || id.isEmpty())id=title;
        JSONArray arr=favorites();String key=kind+":"+id;
        for(int i=0;i<arr.length();i++){JSONObject obj=arr.optJSONObject(i);
            if(obj!=null&&key.equals(obj.optString("key"))){toast("已经收藏过了");return;}}
        try{JSONObject obj=new JSONObject();obj.put("key",key);obj.put("kind",kind);obj.put("id",id);
            obj.put("title",title);obj.put("extra",extra);arr.put(obj);
            prefs().edit().putString("items",arr.toString()).apply();toast("已保存到本地收藏");
        }catch(Exception ex){toast("收藏失败");}
    }
    private void showFavorites(){
        int active=++token;content.removeAllViews();note("本地收藏，不需要登录；卸载 App 可能清除数据。");
        JSONArray arr=favorites();if(arr.length()==0){message("还没有收藏","搜索歌手或专辑，点击 ☆ 收藏即可保存。");return;}
        add(content,"我的收藏（"+arr.length()+"）",17,WHITE,true);content.addView(space(11));
        for(int i=0;i<arr.length();i++){
            JSONObject j=arr.optJSONObject(i);if(j==null)continue;
            String key=j.optString("key"),kind=j.optString("kind"),title=j.optString("title"),extra=j.optString("extra"),id=j.optString("id");
            LinearLayout c=card();add(c,(kind.equals("artist")?"歌手 · ":"专辑 · ")+title,17,WHITE,true);add(c,extra,13,MUTED,false);
            LinearLayout row=actionRow(c);
            addWideButton(row,"Qobuz 搜索",()->openQobuz(kind.equals("artist")?title:extra.split(" · ")[0]+" "+title),true);
            if(kind.equals("artist"))addWideButton(row,"看专辑",()->selectArtist(new MusicService.Artist(id,title,title,"本地收藏")),false);
            addWideButton(row,"删除",()->removeFavorite(key),false);
        }
    }
    private void removeFavorite(String key){
        JSONArray old=favorites(),updated=new JSONArray();
        for(int i=0;i<old.length();i++){JSONObject j=old.optJSONObject(i);if(j!=null&&!key.equals(j.optString("key")))updated.put(j);}
        prefs().edit().putString("items",updated.toString()).apply();showFavorites();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onDestroy(){token++;worker.shutdownNow();artwork.shutdownNow();super.onDestroy();}
}
