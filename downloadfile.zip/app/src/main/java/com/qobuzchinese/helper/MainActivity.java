package com.qobuzchinese.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(12,17,29), CARD = Color.rgb(26,34,52), INPUT = Color.rgb(34,43,62);
    private static final int WHITE = Color.rgb(241,246,252), MUTED = Color.rgb(166,181,198), ACCENT = Color.rgb(72,209,178);
    private static final String STORE = "qobuz_chinese_favorites_v1"; // Keep v1 favorites without data loss.
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ExecutorService artwork = Executors.newFixedThreadPool(2);
    private final Button[] tabs = new Button[3];
    private EditText searchInput;
    private LinearLayout content, searchBar;
    private TextView state, qobuzTermLabel;
    private String qobuzTerm = "";
    private MusicService.Artist currentArtist;
    private int mode = 0, token = 0;
    private String artistQuery = "", albumQuery = "";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setBackgroundColor(BG);
        page.setPadding(dp(16),dp(18),dp(16),dp(8)); setContentView(page);
        page.addView(text("Qobuz 中文音乐助手",24,WHITE,true));
        page.addView(text("中文歌手 → 国际艺名 · Hi-Res 专辑资料 · 收藏",12,MUTED,false));
        page.addView(space(13));
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        tabs[0] = addWideButton(nav,"找歌手",()->switchTab(0),true);
        tabs[1] = addWideButton(nav,"找专辑",()->switchTab(1),false);
        tabs[2] = addWideButton(nav,"我的收藏",()->switchTab(2),false);
        page.addView(nav); page.addView(space(12));
        searchBar = new LinearLayout(this); searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchInput = new EditText(this); searchInput.setSingleLine(true);
        searchInput.setTextSize(16); searchInput.setTextColor(WHITE);
        searchInput.setHintTextColor(MUTED); searchInput.setHint("输入中文歌手名，如：张学友");
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_SEARCH) { search(); return true; }
            return false;
        });
        searchInput.setPadding(dp(12),0,dp(8),0); searchInput.setBackground(round(INPUT,12));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0,dp(51),1);
        ep.setMargins(0,0,dp(8),0); searchBar.addView(searchInput,ep);
        searchBar.addView(button("搜索",this::search,true),new LinearLayout.LayoutParams(dp(84),dp(51)));
        page.addView(searchBar); page.addView(space(9));
        state = text("支持中文、英文、日文艺名；搜索结果请核对歌手身份。",12,MUTED,false);
        page.addView(state);
        // These two shortcuts are always visible, including on the Favorites tab.
        LinearLayout qobuzTools = new LinearLayout(this);
        qobuzTools.setOrientation(LinearLayout.VERTICAL);
        qobuzTools.setPadding(0,dp(8),0,dp(3));
        qobuzTermLabel = text("当前 Qobuz 搜索词：尚未选择",12,MUTED,false);
        qobuzTermLabel.setSingleLine(true);
        qobuzTermLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        qobuzTools.addView(qobuzTermLabel);
        LinearLayout shortcuts = actionRow(qobuzTools);
        addWideButton(shortcuts,"复制搜索词",()->copy(qobuzTerm),true);
        addWideButton(shortcuts,"打开 Qobuz",()->openQobuz(qobuzTerm),false);
        page.addView(qobuzTools);
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true); scroller.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0,dp(12),0,dp(25)); scroller.addView(content);
        page.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot = text("非 Qobuz 官方 App · 不需要 Qobuz 密码 · 本地收藏",11,MUTED,false);
        foot.setGravity(Gravity.CENTER); page.addView(foot);
        showWelcome();
    }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private TextView text(String s,int size,int color,boolean strong) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if (strong) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setLineSpacing(dp(2),1.04f); return v;
    }
    private View space(int size) { View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(size)));return v; }
    private GradientDrawable round(int color,int radius) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14),dp(14),dp(14),dp(14)); c.setBackground(round(CARD,15));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,0,0,dp(11));content.addView(c,p);return c;
    }
    private void add(LinearLayout parent,String s,int size,int color,boolean strong) { parent.addView(text(s,size,color,strong)); }
    private Button button(String title,Runnable action,boolean accent) {
        Button b=new Button(this); b.setText(title); b.setTextSize(12);
        b.setAllCaps(false);b.setPadding(dp(3),0,dp(3),0);
        updateButton(b,accent);b.setOnClickListener(v->action.run());return b;
    }
    private void updateButton(Button b,boolean accent) {
        b.setTextColor(accent?BG:WHITE);b.setBackground(round(accent?ACCENT:INPUT,11));
    }
    private Button addWideButton(LinearLayout row,String title,Runnable action,boolean accent) {
        Button b=button(title,action,accent);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(43),1);
        p.setMargins(dp(2),0,dp(2),0);row.addView(b,p);return b;
    }
    private LinearLayout actionRow(LinearLayout box) {
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,dp(10),0,0);box.addView(row,p);return row;
    }
    private void note(String s) {state.setText(s);}
    private void setQobuzTerm(String val) {
        if (val==null || val.trim().isEmpty())return;
        qobuzTerm=val.trim();
        if (qobuzTermLabel!=null)qobuzTermLabel.setText("当前 Qobuz 搜索词："+qobuzTerm);
    }
    private void toast(String s) {Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void hideKeyboard() {
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(searchInput.getWindowToken(),0);
        searchInput.clearFocus();
    }
    private void selectTabOnly(int selected) {
        mode=selected;
        for (int i=0;i<tabs.length;i++) updateButton(tabs[i],i==mode);
        searchBar.setVisibility(mode==2 ? View.GONE : View.VISIBLE);
        searchInput.setHint(mode==1 ? "输入专辑名，或歌手名查其专辑" : "输入中文歌手名，如：张学友");
    }
    private void switchTab(int selected) {
        final boolean cameFromArtist = mode==0;
        if (mode==0) artistQuery=searchInput.getText().toString();
        if (mode==1) albumQuery=searchInput.getText().toString();
        ++token; selectTabOnly(selected);content.removeAllViews();
        if (selected==0) {
            searchInput.setText(artistQuery);
            note("歌手查询：识别国际艺名，复制后可打开 Qobuz 搜索。");
            showWelcome();
        } else if (selected==1) {
            searchInput.setText(albumQuery.isEmpty()?artistQuery:albumQuery);
            note("专辑查询：可直接搜索专辑，也可按已识别歌手列出专辑。");
            if (cameFromArtist && currentArtist!=null && !artistQuery.isEmpty()
                    && (artistQuery.equalsIgnoreCase(currentArtist.original)
                        || artistQuery.equalsIgnoreCase(currentArtist.name)
                        || artistQuery.equalsIgnoreCase(LocalNames.get(artistQuery)==null?"":LocalNames.get(artistQuery)))) {
                // One tap on 找专辑 after searching a singer immediately lists their albums.
                selectArtist(currentArtist,true);
            } else showAlbumHome();
        } else {
            showFavoritesContent();
        }
    }
    private void showWelcome() {
        content.removeAllViews();LinearLayout intro=card();
        add(intro,"按中文歌手名搜索",19,WHITE,true);
        add(intro,"把中文艺名转成国际艺名，直接复制；点击「看专辑」还会列出该歌手的专辑。",14,MUTED,false);
        add(intro,"\n专辑支持独立复制标题、复制歌手、打开 Qobuz。Hi-Res 规格仍以 Qobuz 实际条目为准。",13,MUTED,false);
        LinearLayout row=actionRow(intro);
        addWideButton(row,"试试：张学友",()->{selectTabOnly(0);searchInput.setText("张学友");search();},true);
        addWideButton(row,"试试：周杰伦",()->{selectTabOnly(0);searchInput.setText("周杰伦");search();},false);
    }
    private void showAlbumHome() {
        content.removeAllViews();LinearLayout intro=card();
        add(intro,"找专辑 · 国际名复制",18,WHITE,true);
        add(intro,"输入专辑中文或英文标题后点击「搜索」。也可以输入歌手名，查找该歌手的专辑。",13,MUTED,false);
        if (currentArtist!=null) {
            add(intro,"\n上次识别歌手："+currentArtist.name,13,ACCENT,true);
            LinearLayout row=actionRow(intro);
            addWideButton(row,"查看此歌手专辑",()->selectArtist(currentArtist,true),true);
            addWideButton(row,"复制歌手名",()->copy(currentArtist.name),false);
        }
        add(intro,"\n专辑原文、已核实的国际名和自动转写会分开标示，避免搜索错误版本。",12,MUTED,false);
    }
    private void message(String heading,String body) {
        LinearLayout c=card();add(c,heading,16,WHITE,true);add(c,body,13,MUTED,false);
    }
    private void search() {
        if (mode==2) {switchTab(0);return;}
        final String query=searchInput.getText().toString().trim();
        if (query.isEmpty()) {toast("请输入歌手或专辑名称");return;}
        if (query.length()>100) {toast("搜索词最多100个字符");return;}
        if (mode==0) artistQuery=query; else albumQuery=query;
        String international = LocalNames.get(query);
        String internationalAlbum = LocalNames.album(query);
        setQobuzTerm(international!=null ? international : internationalAlbum!=null ? internationalAlbum : query);
        hideKeyboard();final int active=++token;content.removeAllViews();note("正在查询音乐资料…");
        if (mode==0) searchArtist(query,active);
        else searchAlbum(query,active);
    }
    private MusicService.Artist offline(String input) {
        String name=LocalNames.get(input);if (name==null)return null;
        MusicService.Artist a=new MusicService.Artist("",name,input,"离线艺名对照");
        a.aliases.add(input);return a;
    }
    private void searchArtist(String query,int active) {
        MusicService.Artist local=offline(query);
        currentArtist=local; // A new query must not reuse an unrelated previous artist.
        if (local!=null)setQobuzTerm(local.name);
        if (local!=null) {
            add(content,"离线国际艺名（可立即复制）",15,ACCENT,true);
            artistCard(local);content.addView(space(9));
        }
        worker.execute(()->{
            try {
                List<MusicService.Artist> found=MusicService.searchArtists(query);
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("找到 "+found.size()+" 条在线歌手记录；请确认歌手身份。");
                    if (currentArtist==null)for (MusicService.Artist candidate:found) {
                        if (query.equalsIgnoreCase(candidate.name)||query.equalsIgnoreCase(candidate.original)) {
                            currentArtist=candidate;break;
                        }
                    }
                    if (found.isEmpty()) {
                        if (local==null) message("无匹配记录","可换简体、繁体、英文艺名尝试。");
                    } else {
                        add(content,"MusicBrainz 在线歌手结果",16,WHITE,true);
                        content.addView(space(9));
                        for (MusicService.Artist a:found) artistCard(a);
                    }
                    if (local==null) manualArtistCard(query);
                });
            } catch (Exception ex) {
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("在线歌手查询失败："+safeError(ex)+"；离线名仍可复制。");
                    if (local==null) manualArtistCard(query);
                });
            }
        });
    }
    private void manualArtistCard(String query) {
        MusicService.Artist a=new MusicService.Artist("",query,query,"手动搜索词");
        add(content,"无法确认时可手动复制搜索",13,MUTED,true);
        artistCard(a);
    }
    private void artistCard(MusicService.Artist a) {
        LinearLayout c=card();add(c,a.name,18,WHITE,true);
        if (!a.original.isEmpty()&&!a.original.equals(a.name)) add(c,"原文："+a.original,12,MUTED,false);
        String info=a.source+(a.country.isEmpty()?"":" · "+a.country)+(a.extra.isEmpty()?"":" · "+a.extra);
        add(c,info,12,MUTED,false);
        if (!a.aliases.isEmpty()) add(c,"别名："+joinNames(a.aliases,5),12,MUTED,false);
        LinearLayout row=actionRow(c);
        addWideButton(row,"转换 / 详情",()->selectArtist(a,false),true);
        addWideButton(row,"复制艺名",()->copy(a.name),false);
        addWideButton(row,"看专辑",()->selectArtist(a,true),false);
        LinearLayout row2=actionRow(c);
        addWideButton(row2,"打开 Qobuz",()->openQobuz(a.name),true);
        addWideButton(row2,"☆ 收藏歌手",()->saveFavorite("artist",a.id,a.name,a.original,a.name,""),false);
    }
    private String joinNames(List<String> names,int limit) {
        StringBuilder b=new StringBuilder();int count=0;
        for (String name:names) {
            if (name.length()>48)continue;
            if (count++>=limit)break;
            if (b.length()>0)b.append(" / ");b.append(name);
        }
        return b.toString();
    }
    private void selectArtist(MusicService.Artist artist,boolean albumsOnly) {
        if (artist==null)return;
        currentArtist=artist;
        setQobuzTerm(artist.name);
        if (mode==0) artistQuery=searchInput.getText().toString();
        if (mode==1) albumQuery=searchInput.getText().toString();
        selectTabOnly(albumsOnly?1:0);
        final int active=++token;
        content.removeAllViews();renderArtist(artist);
        note("正在关联歌手并载入专辑…");
        worker.execute(()->{
            try {
                MusicService.Artist linked=artist;
                if (linked.id==null || !linked.id.matches("[0-9a-fA-F-]{36}")) {
                    linked=MusicService.resolveOfflineArtist(artist);
                }
                if (linked==null) {
                    runOnUiThread(()->{
                        if (active!=token)return;
                        note("未能确认在线歌手身份；国际艺名已可复制，可直接在 Qobuz 搜索。");
                        message("未找到匹配的在线歌手","尝试搜索国际艺名，再选中正确歌手记录。");
                        LinearLayout c=card();
                        addWideButton(actionRow(c),"按国际艺名重新搜索",()->{
                            selectTabOnly(0);searchInput.setText(artist.name);search();},true);
                    });
                    return;
                }
                final MusicService.Artist found=linked;
                try {MusicService.artistDetails(found);}catch(Exception ignored) {}
                final List<MusicService.Album> albums=MusicService.albumsByArtist(found);
                runOnUiThread(()->{
                    if (active!=token)return;
                    currentArtist=found;
                    content.removeAllViews();renderArtist(found);
                    note("已关联 "+found.name+"；找到 "+albums.size()+" 张专辑，复制名字即可到 Qobuz 搜索。");
                    add(content,"专辑 · 可单独复制国际名称",17,WHITE,true);
                    content.addView(space(9));
                    if (albums.isEmpty())message("暂无专辑记录","可换艺名或在 Qobuz 内直接搜索。");
                    for (int i=0;i<Math.min(50,albums.size());i++)albumCard(albums.get(i),active);
                });
                // Preserve the optional artist introduction present in v1.0.
                try {
                    MusicService.Extra extra=MusicService.audioDbArtist(found.name);
                    runOnUiThread(()->{
                        if (active!=token)return;
                        if ((!extra.genre.isEmpty())||(!extra.biography.isEmpty())) {
                            LinearLayout info=card();
                            add(info,"TheAudioDB 歌手简介",15,WHITE,true);
                            if (!extra.genre.isEmpty())add(info,"风格："+extra.genre,13,ACCENT,false);
                            if (!extra.biography.isEmpty())add(info,extra.biography,12,MUTED,false);
                        }
                    });
                } catch (Exception ignored) {}
            } catch (Exception ex) {
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("专辑查询失败："+safeError(ex));
                    message("仍然可以使用国际艺名","点击「复制歌手名」后到 Qobuz 粘贴；也可稍后重试专辑查询。");
                    LinearLayout c=card();
                    addWideButton(actionRow(c),"重试专辑查询",()->selectArtist(artist,albumsOnly),true);
                });
            }
        });
    }
    private void renderArtist(MusicService.Artist a) {
        LinearLayout c=card();add(c,"国际歌手名 · Qobuz 搜索词",14,ACCENT,true);
        add(c,a.name,22,WHITE,true);
        if (a.original!=null&&!a.original.equals(a.name))add(c,"原文名称："+a.original,13,MUTED,false);
        if (a.country!=null&&!a.country.isEmpty())add(c,"地区："+a.country,12,MUTED,false);
        if (!a.aliases.isEmpty())add(c,"其他艺名："+joinNames(a.aliases,8),12,MUTED,false);
        add(c,"\n搜索词可在下框手动修改，按复制后在 Qobuz 搜索栏粘贴。",12,MUTED,false);
        EditText edit=new EditText(this);edit.setSingleLine(true);edit.setText(a.name);
        edit.setTextColor(WHITE);edit.setTextSize(17);edit.setBackground(round(INPUT,11));
        edit.setPadding(dp(12),0,dp(12),0);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(8),0,0);c.addView(edit,p);
        LinearLayout row=actionRow(c);
        addWideButton(row,"复制国际名",()->copy(edit.getText().toString()),true);
        addWideButton(row,"打开 Qobuz",()->openQobuz(edit.getText().toString()),false);
        LinearLayout row2=actionRow(c);
        addWideButton(row2,"看专辑",()->selectArtist(a,true),true);
        addWideButton(row2,"☆ 收藏歌手",()->saveFavorite("artist",a.id,a.name,a.original,a.name,""),false);
        addWideButton(row2,"网页搜索",()->webQobuz(edit.getText().toString()),false);
        LinearLayout row3=actionRow(c);
        addWideButton(row3,"返回搜索",()->{
            selectTabOnly(0);
            searchInput.setText(artistQuery.isEmpty()?a.original:artistQuery);
            search();
        },false);
        add(c,"\n打开 Qobuz 会先复制搜索词；由于第三方 App 限制，仍需在 Qobuz 搜索框粘贴。",12,MUTED,false);
    }
    private void searchAlbum(String query,int active) {
        MusicService.Artist local=offline(query);
        if (local!=null || LocalNames.isKnownInternationalArtist(query)) {
            // Chinese or known international artist names should open their albums
            // immediately, instead of being treated as album titles.
            selectArtist(local!=null?local:
                new MusicService.Artist("",query,query,"国际艺名对照"),true);
            return;
        }
        worker.execute(()->{
            try {
                List<MusicService.Album> albums=MusicService.searchAlbums(query);
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("按专辑名称找到 "+albums.size()+" 条记录（不代表 Qobuz 一定收录）。");
                    if (albums.isEmpty()) {
                        message("没有找到同名专辑","可输入国际名称，或者使用下方按歌手查询。");
                        LinearLayout c=card();
                        addWideButton(actionRow(c),"将此名称作为歌手查询",()->{
                            MusicService.Artist a=offline(query);
                            if (a!=null)selectArtist(a,true);
                            else searchSingerAlbums(query);
                        },true);
                    } else {
                        add(content,"专辑查询结果",17,WHITE,true);content.addView(space(9));
                        for (MusicService.Album album:albums) albumCard(album,active);
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("专辑在线查询失败："+safeError(ex));
                    message("网络暂时无法查询","请确认网络连接后重试，或输入艺名到 Qobuz 搜索。");
                });
            }
        });
    }
    private void searchSingerAlbums(String query) {
        final int active=++token;
        content.removeAllViews();note("正在查找歌手，再列出对应专辑…");
        worker.execute(()->{
            try {
                List<MusicService.Artist> artists=MusicService.searchArtists(query);
                runOnUiThread(()->{
                    if (active!=token)return;
                    if (artists.isEmpty()) {message("找不到歌手","可尝试输入国际艺名。");return;}
                    note("请选择正确歌手，查看他的专辑。");
                    for (MusicService.Artist a:artists)artistCard(a);
                });
            }catch(Exception ex){runOnUiThread(()->{
                if (active!=token)return;
                note("在线歌手查询失败："+safeError(ex));
            });}
        });
    }
    private void albumCard(MusicService.Album a,int active) {
        LinearLayout c=card();LinearLayout horizontal=new LinearLayout(this);
        horizontal.setOrientation(LinearLayout.HORIZONTAL);c.addView(horizontal);
        ImageView cover=new ImageView(this);cover.setImageResource(android.R.drawable.ic_menu_gallery);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);cover.setBackground(round(INPUT,8));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(79),dp(79));
        cp.setMargins(0,0,dp(12),0);horizontal.addView(cover,cp);
        LinearLayout infos=new LinearLayout(this);infos.setOrientation(LinearLayout.VERTICAL);
        horizontal.addView(infos,new LinearLayout.LayoutParams(0,-2,1));
        add(infos,a.name,16,WHITE,true);
        if (a.artist!=null&&!a.artist.isEmpty()) {
            add(infos,"歌手："+a.artist,12,ACCENT,false);
            if (a.artistOriginal!=null&&!a.artistOriginal.equals(a.artist))
                add(infos,"原文艺名："+a.artistOriginal,11,MUTED,false);
        }
        add(infos,"首次发行："+(a.year.isEmpty()?"未知":a.year)+(a.type.isEmpty()?"":" · "+a.type),12,MUTED,false);
        TextView alias=text(a.searchLabel(),13,ACCENT,false);
        LinearLayout.LayoutParams labelParams=new LinearLayout.LayoutParams(-1,-2);
        labelParams.setMargins(0,dp(8),0,0);c.addView(alias,labelParams);
        LinearLayout row=actionRow(c);
        addWideButton(row,"复制专辑名",()->copy(a.searchTitle()),true);
        addWideButton(row,"复制歌手",()->copy(a.artist),false);
        addWideButton(row,"打开 Qobuz",()->openQobuz(a.searchTitle()),false);
        LinearLayout second=actionRow(c);
        addWideButton(second,"查国际名",()->lookupAlbumName(a,alias,active),true);
        addWideButton(second,"版本 / 公司",()->albumDetails(a),false);
        addWideButton(second,"☆ 收藏",()->saveFavorite("album",a.id,a.name,a.artist+" · "+a.year,a.searchTitle(),a.artist),false);
        if (a.id!=null&&!a.id.isEmpty()) artwork.execute(()->{
            Bitmap bitmap=MusicService.fetchCover(a.imageUrl());
            if (bitmap!=null)runOnUiThread(()->{
                if (active==token&&!isFinishing())cover.setImageBitmap(bitmap);
            });
        });
    }
    private void lookupAlbumName(MusicService.Album album,TextView display,int active) {
        if (album.id==null||album.id.isEmpty()) {toast("缺少专辑 ID，无法查询发行名");return;}
        note("正在查找专辑其他发行标题…");
        worker.execute(()->{
            try {
                List<String> names=MusicService.alternateReleaseTitles(album);
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("专辑国际名查询已完成。可复制并在 Qobuz 搜索。");
                    if (names.isEmpty()) {
                        display.setText(album.searchLabel());
                        new AlertDialog.Builder(this).setTitle("国际专辑名")
                            .setMessage("没有找到可靠的拉丁字母发行标题。\n\n"+album.searchLabel()
                                +"\n\n如果只有拼音转写，它不是官方英文专辑名；可继续用中文原名或拼音尝试搜索。")
                            .setPositiveButton("复制当前搜索词",(d,w)->copy(album.searchTitle()))
                            .setNegativeButton("关闭",null).show();
                        return;
                    }
                    ArrayList<String> options=new ArrayList<>(names);
                    // Allow the user to keep the earlier source name or select a verified release variant.
                    if (!album.international.isEmpty()&&!options.contains(album.international))options.add(0,album.international);
                    new AlertDialog.Builder(this).setTitle("选择实际发行标题")
                        .setSingleChoiceItems(options.toArray(new String[0]),-1,(dialog,which)->{
                            album.international=options.get(which);
                            album.source="MusicBrainz 发行版本标题";
                            display.setText(album.searchLabel());
                            copy(album.international);
                            dialog.dismiss();
                        }).setNegativeButton("取消",null).show();
                });
            } catch (Exception ex) {
                runOnUiThread(()->{
                    if (active!=token)return;
                    note("国际名查询暂时失败："+safeError(ex));
                    toast("仍可复制目前显示的专辑搜索词");
                });
            }
        });
    }
    private void albumDetails(MusicService.Album a) {
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(a.name)
            .setMessage("正在查询版本和唱片公司…")
            .setPositiveButton("关闭",(d,w)->{}).create();dialog.show();
        worker.execute(()->{
            try {
                String details=MusicService.albumEditionDetails(a);
                runOnUiThread(()->{if (!isFinishing()&&dialog.isShowing())dialog.setMessage(details);});
            } catch (Exception ex) {
                runOnUiThread(()->{if (!isFinishing()&&dialog.isShowing())dialog.setMessage("查询失败："+safeError(ex));});
            }
        });
    }
    private String safeError(Exception e) {
        String s=e.getMessage();return s==null||s.trim().isEmpty()?"服务超时或连接失败":s;
    }
    private boolean copy(String val) {
        if (val==null||val.trim().isEmpty()) {toast("请先搜索并选择歌手或专辑名称");return false;}
        setQobuzTerm(val);
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("Qobuz 搜索词",val.trim()));
        toast("已复制："+val.trim());return true;
    }
    private void openQobuz(String val) {
        if (!copy(val))return;
        Intent intent=getPackageManager().getLaunchIntentForPackage("com.qobuz.music");
        if (intent==null) {
            toast("未找到 Qobuz App，改为打开网页版；搜索词已复制。");
            openUrl("https://play.qobuz.com/");return;
        }
        try {startActivity(intent);}catch(Exception e) {
            toast("无法启动 Qobuz，可手动打开并粘贴已复制的搜索词。");
        }
    }
    private void webQobuz(String val) {
        if (!copy(val))return;
        // A reliable query-prefilled Qobuz URL is not publicly documented.
        // Open the web player; paste the already-copied term in its Search box.
        openUrl("https://play.qobuz.com/");
    }
    private void openUrl(String url) {
        try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
        catch(Exception e){toast("无法打开网页，请检查浏览器。搜索词仍在剪贴板。");}
    }
    private SharedPreferences prefs() {return getSharedPreferences(STORE,MODE_PRIVATE);}
    private JSONArray favorites() {
        try {return new JSONArray(prefs().getString("items","[]"));}
        catch(Exception e){return new JSONArray();}
    }
    private void saveFavorite(String kind,String id,String title,String extra,String searchTitle,String artist) {
        if (id==null||id.isEmpty())id=title;
        JSONArray arr=favorites();String key=kind+":"+id;
        for (int i=0;i<arr.length();i++) {
            JSONObject obj=arr.optJSONObject(i);
            if (obj!=null&&key.equals(obj.optString("key"))) {toast("已经收藏过了");return;}
        }
        try {
            JSONObject obj=new JSONObject();obj.put("key",key);obj.put("kind",kind);
            obj.put("id",id);obj.put("title",title);obj.put("extra",extra);
            obj.put("searchTitle",searchTitle);obj.put("artist",artist);
            arr.put(obj);prefs().edit().putString("items",arr.toString()).apply();
            toast("已保存到我的收藏");
        }catch(Exception ex){toast("收藏保存失败");}
    }
    private void showFavoritesContent() {
        content.removeAllViews();note("本地收藏，不需要登录；卸载 App 可能清除数据。");
        JSONArray arr=favorites();
        if (arr.length()==0) {message("还没有收藏","搜索歌手或专辑，点击 ☆ 收藏即可保存。");return;}
        add(content,"我的收藏（"+arr.length()+"）",17,WHITE,true);content.addView(space(11));
        for (int i=0;i<arr.length();i++) {
            JSONObject obj=arr.optJSONObject(i);if (obj==null)continue;
            String key=obj.optString("key"),kind=obj.optString("kind"),title=obj.optString("title"),
                extra=obj.optString("extra"),id=obj.optString("id");
            String artist=obj.optString("artist");
            if (!kind.equals("artist")&&artist.isEmpty()) {
                int pos=extra.lastIndexOf(" · ");
                artist=pos>=0?extra.substring(0,pos):extra; // v1 collection migration.
            }
            String international=obj.optString("searchTitle","");
            if (international.isEmpty()) {
                // Older v1 album favorites had only Chinese titles; preserve and enrich them.
                international=kind.equals("artist") ? title
                    : new MusicService.Album(id,title,"","",artist).searchTitle();
            }
            final String targetArtist=artist,targetTitle=international;
            LinearLayout c=card();
            add(c,(kind.equals("artist")?"歌手 · ":"专辑 · ")+title,17,WHITE,true);
            if (!extra.isEmpty())add(c,extra,13,MUTED,false);
            if (!kind.equals("artist")&&!targetTitle.equals(title))
                add(c,"搜索词（国际名或转写备选）："+targetTitle,13,ACCENT,false);
            LinearLayout row=actionRow(c);
            addWideButton(row,kind.equals("artist")?"复制艺名":"复制专辑",()->copy(targetTitle),true);
            addWideButton(row,"打开 Qobuz",()->openQobuz(targetTitle),false);
            LinearLayout second=actionRow(c);
            if (kind.equals("artist")) {
                addWideButton(second,"看专辑",()->selectArtist(
                    new MusicService.Artist(id,title,extra.isEmpty()?title:extra,"本地收藏"),true),false);
            } else {
                addWideButton(second,"复制歌手",()->copy(targetArtist),false);
            }
            addWideButton(second,"删除",()->removeFavorite(key),false);
        }
    }
    private void removeFavorite(String key) {
        JSONArray old=favorites(),updated=new JSONArray();
        for (int i=0;i<old.length();i++) {
            JSONObject obj=old.optJSONObject(i);
            if (obj!=null&&!key.equals(obj.optString("key")))updated.put(obj);
        }
        prefs().edit().putString("items",updated.toString()).apply();
        selectTabOnly(2);++token;showFavoritesContent();
    }
    @Override public void onDestroy() {
        ++token;worker.shutdownNow();artwork.shutdownNow();super.onDestroy();
    }
}
