package com.qobuzchinese.helper;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
public final class LocalNames {
    private static final Map<String,String> NAMES;
    static {
        LinkedHashMap<String,String> m=new LinkedHashMap<>();
        m.put("邓丽君","Teresa Teng"); m.put("鄧麗君","Teresa Teng");
        m.put("周杰伦","Jay Chou"); m.put("周杰倫","Jay Chou");
        m.put("张学友","Jacky Cheung"); m.put("張學友","Jacky Cheung");
        m.put("王菲","Faye Wong"); m.put("刘德华","Andy Lau");m.put("劉德華","Andy Lau");
        m.put("林俊杰","JJ Lin");m.put("林俊傑","JJ Lin");
        m.put("蔡依林","Jolin Tsai");m.put("孙燕姿","Stefanie Sun");m.put("孫燕姿","Stefanie Sun");
        m.put("陈奕迅","Eason Chan");m.put("陳奕迅","Eason Chan");
        m.put("王力宏","Wang Leehom");m.put("莫文蔚","Karen Mok");
        m.put("张惠妹","A-Mei");m.put("張惠妹","A-Mei");
        m.put("李宗盛","Jonathan Lee");m.put("伍佰","Wu Bai");
        m.put("许巍","Xu Wei");m.put("許巍","Xu Wei");
        m.put("许嵩","Vae Xu");m.put("許嵩","Vae Xu");
        m.put("萧敬腾","Jam Hsiao");m.put("蕭敬騰","Jam Hsiao");
        m.put("田馥甄","Hebe Tien");m.put("梁静茹","Fish Leong");m.put("梁靜茹","Fish Leong");
        m.put("杨丞琳","Rainie Yang");m.put("楊丞琳","Rainie Yang");
        m.put("蔡健雅","Tanya Chua");m.put("陶喆","David Tao");
        m.put("潘玮柏","Wilber Pan");m.put("潘瑋柏","Wilber Pan");
        m.put("郭富城","Aaron Kwok");m.put("黎明","Leon Lai");
        m.put("谢霆锋","Nicholas Tse");m.put("謝霆鋒","Nicholas Tse");
        m.put("陈慧琳","Kelly Chen");m.put("陳慧琳","Kelly Chen");
        m.put("张国荣","Leslie Cheung");m.put("張國榮","Leslie Cheung");
        m.put("梅艳芳","Anita Mui");m.put("梅艷芳","Anita Mui");
        m.put("谭咏麟","Alan Tam");m.put("譚詠麟","Alan Tam");
        m.put("容祖儿","Joey Yung");m.put("容祖兒","Joey Yung");
        m.put("宇多田光","Hikaru Utada");m.put("坂本龙一","Ryuichi Sakamoto");m.put("坂本龍一","Ryuichi Sakamoto");
        m.put("米津玄师","Kenshi Yonezu");m.put("米津玄師","Kenshi Yonezu");
        m.put("滨崎步","Ayumi Hamasaki");m.put("濱崎步","Ayumi Hamasaki");
        m.put("中岛美嘉","Mika Nakashima");m.put("中島美嘉","Mika Nakashima");
        m.put("山口百惠","Momoe Yamaguchi");m.put("松任谷由实","Yumi Matsutoya");m.put("松任谷由実","Yumi Matsutoya");
        m.put("李圣杰","Sam Lee");m.put("李聖傑","Sam Lee");
        m.put("五月天","Mayday");m.put("苏打绿","Sodagreen");m.put("蘇打綠","Sodagreen");
        m.put("信乐团","Shin Band");m.put("信樂團","Shin Band");
        m.put("动力火车","Power Station");m.put("動力火車","Power Station");
        m.put("韩红","Han Hong");m.put("韓紅","Han Hong");
        m.put("那英","Na Ying");m.put("李健","Li Jian");
        NAMES=Collections.unmodifiableMap(m);
    }
    /** Curated romanized or official album titles; not an exhaustive translation dictionary. */
    static String album(String original) {
        String n = original == null ? "" : original.trim();
        switch (n) {
            case "范特西": case "范特西!": return "Fantasy";
            case "葉惠美": case "叶惠美": return "Yeh Hui Mei";
            case "十一月的蕭邦": case "十一月的萧邦": return "November's Chopin";
            case "跨時代": case "跨时代": return "The Era";
            case "八度空間": case "八度空间": return "The Eight Dimensions";
            default: return null;
        }
    }
    static String get(String original) { return original==null?null:NAMES.get(original.trim()); }
    static boolean isKnownInternationalArtist(String input) {
        if (input==null)return false;
        for (String name:NAMES.values()) if (name.equalsIgnoreCase(input.trim()))return true;
        return false;
    }
    static Map<String,String> all() { return NAMES; }
}
