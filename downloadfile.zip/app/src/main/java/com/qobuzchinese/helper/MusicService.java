package com.qobuzchinese.helper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.icu.text.Transliterator;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Only publicly available music metadata; no private Qobuz API or Qobuz credentials. */
public final class MusicService {
    private static final String MB = "https://musicbrainz.org/ws/2/";
    private static long lastMbCall = 0;
    private static final String AGENT = "QobuzChineseHiResHelper/1.2 (https://github.com/weixiaoyinjie)";

    static final class Artist {
        String id, name, original, country, extra, source;
        int score;
        final ArrayList<String> aliases = new ArrayList<>();
        Artist(String id, String name, String original, String source) {
            this.id = id; this.name = name; this.original = original; this.source = source;
            this.country = ""; this.extra = "";
        }
    }
    static final class Album {
        String id, name, year, type, artist, artistOriginal, label;
        String international = "", source = "", romanized = "";
        Album(String id, String name, String year, String type, String artist) {
            this.id = id; this.name = name; this.year = year; this.type = type;
            this.artistOriginal = artist == null ? "" : artist;
            this.artist = internationalArtist(this.artistOriginal);
            this.label = "";
            if (isLatinName(name)) { international = name; source = "原始发行名"; }
            else {
                String known = LocalNames.album(name);
                if (known != null) { international = known; source = "离线专辑名对照（请核对版本）"; }
                romanized = romanize(name);
            }
        }
        String imageUrl() { return "https://coverartarchive.org/release-group/" + id + "/front-250"; }
        String searchTitle() {
            return !international.isEmpty() ? international : (!romanized.isEmpty() ? romanized : name);
        }
        String searchLabel() {
            if (!international.isEmpty()) return international.equals(name) ? "专辑搜索词：" + international : "国际专辑名：" + international + " · " + source;
            if (!romanized.isEmpty()) return "拉丁字母转写：" + romanized + "（非官方英文标题）";
            return "国际专辑名暂无可靠记录，可先复制原文搜索";
        }
    }
    static final class Extra { String biography = "", genre = "", image = ""; }

    private static String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception ignored) { return s; } }
    private static String opt(JSONObject j, String key) { return j == null ? "" : j.optString(key, ""); }

    private static synchronized void limitMusicBrainz() throws InterruptedException {
        long now = System.currentTimeMillis();
        long wait = 1150 - (now - lastMbCall);
        if (wait > 0) Thread.sleep(wait);
        lastMbCall = System.currentTimeMillis();
    }
    private static byte[] request(String address, boolean isMb, int cap) throws Exception {
        if (isMb) limitMusicBrainz();
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        try {
            c.setRequestMethod("GET");
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", AGENT);
            c.setRequestProperty("Accept", "application/json");
            c.setConnectTimeout(10000);
            c.setReadTimeout(12000);
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("音乐资料服务暂不可用 (HTTP " + code + ")");
            try (InputStream stream = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b = new byte[8192]; int n;
                while ((n = stream.read(b)) != -1) {
                    out.write(b, 0, n);
                    if (out.size() > cap) throw new Exception("服务器返回内容过大");
                }
                return out.toByteArray();
            }
        } finally { c.disconnect(); }
    }
    private static JSONObject json(String address, boolean mb) throws Exception {
        return new JSONObject(new String(request(address, mb, 3_000_000), StandardCharsets.UTF_8));
    }
    static Bitmap fetchCover(String url) {
        try {
            byte[] data = request(url, false, 1_200_000);
            return BitmapFactory.decodeByteArray(data, 0, data.length);
        } catch (Exception ignored) { return null; }
    }
    private static boolean isLatinName(String s) {
        return s != null && s.matches(".*[A-Za-z].*") && !s.matches(".*[\\u4e00-\\u9fff\\u3040-\\u30ff\\uac00-\\ud7af].*");
    }
    static String romanize(String name) {
        if (name == null || name.isEmpty() || !name.matches(".*[\\u4e00-\\u9fff\\u3040-\\u30ff].*")) return "";
        try {
            String value = Transliterator.getInstance("Any-Latin; Latin-ASCII").transliterate(name)
                .replaceAll("\\s+", " ").trim();
            return isLatinName(value) && !value.equals(name) ? value : "";
        } catch (Exception e) { return ""; }
    }
    /** Known stage names first; unknown CJK names can only be transliterated, not verified. */
    private static String internationalArtist(String name) {
        if (name == null || name.isEmpty()) return "";
        String known = LocalNames.get(name);
        if (known != null) return known;
        String latin = romanize(name);
        return latin.isEmpty() ? name : latin;
    }
    private static void addAlias(Artist a, String alias) {
        if (alias != null && !alias.isEmpty() && !a.aliases.contains(alias) && a.aliases.size() < 20) a.aliases.add(alias);
    }
    private static String preferLatin(String current, JSONArray aliases) {
        if (isLatinName(current)) return current;
        if (aliases == null) return current;
        String first = "";
        for (int i = 0; i < aliases.length(); i++) {
            JSONObject al = aliases.optJSONObject(i);
            if (al == null) continue;
            String name = opt(al, "name"), locale = opt(al, "locale");
            if (!isLatinName(name)) continue;
            if (first.isEmpty()) first = name;
            if (locale.toLowerCase(Locale.ROOT).startsWith("en")) return name;
        }
        return first.isEmpty() ? current : first;
    }
    static List<Artist> searchArtists(String query) throws Exception {
        JSONObject obj = json(MB + "artist/?query=" + enc(query.trim()) + "&limit=12&fmt=json", true);
        JSONArray rows = obj.optJSONArray("artists");
        List<Artist> result = new ArrayList<>();
        if (rows == null) return result;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject item = rows.optJSONObject(i);
            if (item == null) continue;
            String name = opt(item, "name"), id = opt(item, "id");
            if (name.isEmpty() || id.isEmpty()) continue;
            Artist a = new Artist(id, name, name, "MusicBrainz");
            a.score = item.optInt("score", 0);
            a.country = opt(item, "country"); a.extra = opt(item, "disambiguation");
            JSONArray aliases = item.optJSONArray("aliases");
            if (aliases != null) for (int k = 0; k < aliases.length(); k++) {
                JSONObject alias = aliases.optJSONObject(k);
                if (alias != null) addAlias(a, opt(alias, "name"));
            }
            a.name = preferLatin(a.name, aliases);
            result.add(a);
        }
        return result;
    }
    /** Only resolve an offline alias to a clearly matching MusicBrainz identity. */
    static Artist resolveOfflineArtist(Artist offline) throws Exception {
        if (offline.id != null && offline.id.matches("[0-9a-fA-F-]{36}")) return offline;
        List<Artist> candidates = searchArtists(offline.name);
        Artist best = null;
        for (Artist a : candidates) {
            boolean same = a.name.equalsIgnoreCase(offline.name)
                || a.original.equalsIgnoreCase(offline.name);
            for (String alias : a.aliases) if (alias.equalsIgnoreCase(offline.name)) same = true;
            if (same && (best == null || a.score > best.score)) best = a;
        }
        return best;
    }
    static Artist artistDetails(Artist a) throws Exception {
        if (a.id == null || a.id.isEmpty()) return a;
        JSONObject obj = json(MB + "artist/" + enc(a.id) + "?inc=aliases&fmt=json", true);
        String original = opt(obj, "name");
        if (!original.isEmpty()) a.original = original;
        a.country = opt(obj, "country"); a.extra = opt(obj, "disambiguation");
        JSONArray aliases = obj.optJSONArray("aliases");
        if (aliases != null) for (int k = 0; k < aliases.length(); k++) {
            JSONObject alias = aliases.optJSONObject(k);
            if (alias != null) addAlias(a, opt(alias, "name"));
        }
        a.name = preferLatin(a.original, aliases);
        return a;
    }
    private static List<Album> parseAlbums(JSONObject obj) {
        List<Album> result = new ArrayList<>();
        JSONArray rows = obj.optJSONArray("release-groups");
        if (rows == null) return result;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String id = opt(row, "id"), title = opt(row, "title"), artist = "";
            if (id.isEmpty() || title.isEmpty()) continue;
            JSONArray credits = row.optJSONArray("artist-credit");
            if (credits != null) for (int k = 0; k < credits.length(); k++) {
                JSONObject credit = credits.optJSONObject(k);
                if (credit == null) continue;
                JSONObject ar = credit.optJSONObject("artist");
                if (ar != null) { artist = opt(ar, "name"); break; }
            }
            result.add(new Album(id, title, opt(row, "first-release-date"), opt(row, "primary-type"), artist));
        }
        return result;
    }
    static List<Album> searchAlbums(String query) throws Exception {
        JSONObject first = json(MB + "release-group/?query=" + enc(query.trim()) + "&limit=20&fmt=json", true);
        List<Album> result = parseAlbums(first);
        if (result.isEmpty()) {
            // The default index searches title, not aliases; explicitly retry aliases.
            JSONObject byAlias = json(MB + "release-group/?query=" + enc("alias:\"" + query.trim().replace("\"", "") + "\"") + "&limit=20&fmt=json", true);
            result = parseAlbums(byAlias);
        }
        return result;
    }
    static List<Album> albumsByArtist(Artist a) throws Exception {
        List<Album> result = new ArrayList<>();
        if (a.id == null || !a.id.matches("[0-9a-fA-F-]{36}")) return result;
        JSONObject obj = json(MB + "release-group/?artist=" + enc(a.id) + "&type=album&limit=50&fmt=json", true);
        JSONArray rows = obj.optJSONArray("release-groups");
        if (rows == null) return result;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String id = opt(row, "id"), title = opt(row, "title");
            if (id.isEmpty() || title.isEmpty()) continue;
            result.add(new Album(id, title, opt(row, "first-release-date"), opt(row, "primary-type"), a.name));
        }
        result.sort((x, y) -> y.year.compareTo(x.year));
        return result;
    }
    /** Uses only real alternate release titles; it does not fabricate English translations. */
    static List<String> alternateReleaseTitles(Album album) throws Exception {
        List<String> titles = new ArrayList<>();
        if (album.id == null || album.id.isEmpty()) return titles;
        JSONObject obj = json(MB + "release/?release-group=" + enc(album.id) + "&limit=80&fmt=json", true);
        JSONArray rows = obj.optJSONArray("releases");
        if (rows == null) return titles;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject rel = rows.optJSONObject(i);
            String candidate = opt(rel, "title").trim();
            if (isLatinName(candidate) && !candidate.equalsIgnoreCase(album.name)
                    && candidate.length() <= 150 && !titles.contains(candidate)) titles.add(candidate);
        }
        return titles;
    }
    static String albumEditionDetails(Album album) throws Exception {
        if (album.id == null || album.id.isEmpty()) return "没有可查询的 MusicBrainz 专辑 ID。";
        JSONObject listing = json(MB + "release/?release-group=" + enc(album.id) + "&limit=8&fmt=json", true);
        JSONArray rows = listing.optJSONArray("releases");
        if (rows == null || rows.length() == 0) return "MusicBrainz 暂无发行版本资料。";
        JSONObject first = rows.optJSONObject(0);
        if (first == null) return "缺少版本资料";
        StringBuilder out = new StringBuilder("发行版本（前 " + rows.length() + " 条）：\n");
        for (int i = 0; i < rows.length(); i++) {
            JSONObject r = rows.optJSONObject(i);
            if (r == null) continue;
            out.append("• ").append(opt(r, "date")).append("  ").append(opt(r, "country"));
            String dis = opt(r, "disambiguation");
            if (!dis.isEmpty()) out.append("  ").append(dis);
            String title = opt(r, "title");
            if (!title.isEmpty() && !title.equalsIgnoreCase(album.name)) out.append("  ").append(title);
            out.append("\n");
        }
        String releaseId = opt(first, "id");
        if (!releaseId.isEmpty()) {
            JSONObject detail = json(MB + "release/" + enc(releaseId) + "?inc=labels+media&fmt=json", true);
            JSONArray labels = detail.optJSONArray("label-info");
            if (labels != null) for (int i = 0; i < labels.length(); i++) {
                JSONObject entry = labels.optJSONObject(i);
                if (entry == null) continue;
                JSONObject label = entry.optJSONObject("label");
                if (label != null && !opt(label, "name").isEmpty()) out.append("唱片公司：").append(opt(label, "name")).append("\n");
                if (!opt(entry, "catalog-number").isEmpty()) out.append("目录编号：").append(opt(entry, "catalog-number")).append("\n");
            }
            JSONArray media = detail.optJSONArray("media");
            if (media != null && media.length() > 0) {
                JSONObject m = media.optJSONObject(0);
                if (m != null) out.append("发行媒介：").append(opt(m, "format")).append("\n");
            }
        }
        out.append("\n发行记录不代表 Qobuz 提供此版本或其 Hi-Res 规格。");
        return out.toString();
    }
    static Extra audioDbArtist(String name) throws Exception {
        JSONObject obj = json("https://www.theaudiodb.com/api/v1/json/123/search.php?s=" + enc(name), false);
        Extra x = new Extra();
        JSONArray rows = obj.optJSONArray("artists");
        if (rows == null || rows.length() == 0) return x;
        JSONObject a = rows.optJSONObject(0);
        if (a == null) return x;
        x.genre = opt(a, "strGenre"); x.image = opt(a, "strArtistThumb");
        x.biography = opt(a, "strBiographyCN");
        if (x.biography.isEmpty()) x.biography = opt(a, "strBiographyEN");
        if (x.biography.length() > 600) x.biography = x.biography.substring(0, 600) + "…";
        return x;
    }
}
