# Qobuz 中文 Hi-Res 音乐资料助手 v1.2

A standalone Android metadata discovery helper using MusicBrainz, Cover Art Archive, and (optional) TheAudioDB, **not an official Qobuz client**.

## v1.2 repair

- The three top-level tabs are now stateful, clearly highlighted in green when selected.
- All three tabs always show a selected Qobuz search term with dedicated Copy and Open Qobuz actions, including Favorites.
- Every artist result card also has Copy Name and Open Qobuz; album cards and Favorites entries have both actions side by side.
- Typing an offline-known singer directly in Find Album opens that singer’s albums without an extra button tap.
- Album tab has its own landing view, and can search albums by title or find albums for an artist.
- Offline artist name conversions (e.g. 张学友 → Jacky Cheung) can be resolved through MusicBrainz to a verified artist ID before fetching their albums.
- Every album provides separate copy-album, copy-artist, open-Qobuz, alternate-release-title, editions/labels, and favorite actions.
- Original album title, official/curated English spelling, MusicBrainz alternate-release title, and phonetic transliteration are **distinguished**. Transliteration is explicitly not asserted to be the official translated title.
- Older v1 local favorites are kept and remain readable.
- Qobuz buttons copy terms to the clipboard first, then launch its Android App or the web player. The user pastes the term manually. We do not claim a working auto-filled Qobuz search URL.

## Build

1. Upload `QobuzChineseHiResHelper_v1.2_功能修复完整源码.zip` to your existing GitHub repository (preferably remove older ZIP files).
2. Replace `.github/workflows/build-apk.yml` with the file inside this ZIP or the separately provided YAML file.
3. In Actions, run **Build Qobuz Chinese Helper APK**.
4. Download the `QobuzChineseHiResHelper-v1_2-debug` build artifact and unzip `app-debug.apk`.

JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2, compile SDK 35, minimum Android 8 (API 26). Only public metadata endpoints are called. Local favorites use the same preferences store as v1.

This source was statically reviewed but **not built or device-tested in the delivery environment**, which lacks an Android SDK. Google/GitHub CI build and on-device user acceptance tests are required.

See `README_中文使用说明.txt` for a detailed Chinese test checklist.
